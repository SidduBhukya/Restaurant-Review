<h1>Chalo_Restro</h1>
<p>
  This is a full-stack web application for restaurant management, featuring adding, editing,
  and reviewing restaurants, as well as photo uploads and additional functionalities such as user authentication.
  Only users who added a restaurant can delete or update it, ensuring control and accountability.
</p>
